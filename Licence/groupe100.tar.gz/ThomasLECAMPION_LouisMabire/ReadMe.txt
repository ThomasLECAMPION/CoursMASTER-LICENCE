Nous avons implémenté toutes les fonctionnalités jusque la partie "J - Le retour des boucles : le for et le repeat ... until"
(La calculette ne gert pas encore les flottants)
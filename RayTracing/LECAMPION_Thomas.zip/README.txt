LECAMPION Thomas, IMAGINE
Rendu final du projet de ray tracing.

compile:
g++ -o main main.cpp
run:
./main > image.ppm
